Meowa Godot 4 combined sprite export

Copy the 1-animations folder into an existing Godot 4 project.
Drag 1-animations.tscn from the FileSystem dock into your scene.
The shared SpriteFrames resource contains: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43.
No project.godot file is included, so existing project settings are not replaced.
